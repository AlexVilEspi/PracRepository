// // Filename: ReviewProgram.cpp
// Author: Juan Villafuerte
// Date: 09/27/2022
// Summary: testing of the test course

#include "ReviewProgram.h"
#include<iostream>
#include<string>
using namespace std;

int main()
{
    Course c1("23sss","ssss",3,"ssddsd","ssdsd22");
    cout << "Here is the information of the course inputted abouve\n\n\n";
    c1.print_Courses();
    Course c2;
    cout <<"\n\nNow its the turn of the user to input course info..\n";

    c2.SetCourseInfo();

    int userinput;

    cout << "from what course are you looking for information for (1-5) ? ";
    cin >> userinput;
    cout << "Here is the information for course " << userinput;
    cout << endl << endl;
    cout <<"Course Code: " <<c2.CourseCode[userinput];
    cout <<"Course Num: " << c2.CourseNum[userinput] << endl;
    cout <<"Course Credits: " << c2.CourseCred[userinput] << endl;
    cout << "Instructor LastName: " << c2.CourseLast[userinput] << endl;
    cout << "Course Location: " << c2.CourseLoc[userinput] << endl;


    cout << "\n\n";


    c2.print_Courses_Entered();


















}
