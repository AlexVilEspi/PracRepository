// Filename: ReviewProgram.h
// Author: Juan Villafuerte
// Date: 09/27/2022
// Summary: Define a class, Course, to represent a college course.

#ifndef REVIEW_H
#define REVIEW_H
#include <string>
#include<iostream>

/*
 Comments: Classes were the one thing I didnt have time to study for
 which made me struggle on this review program since I didnt have
 time to go over the material.

 I was trying to make a 5d multi dimensional array for the course info
 but problems were occuring. I commented out the code for that section.
 I was trying to make it so that we can loop everything out so that it would]
 look cooler but the location array was causing problems due to it repeating more
 that it was supposed to do.


 I dont know why but the last array keeps looping twice for the first one
 but none of the rest do.

 I think this project would be easier if we did it instead with a struct
 because the array section of this lab would be easier..
*/

class Course
{
public:
    Course(); // default constructor
    Course(std::string,std::string,int,std::string,std::string);



    void setCourseCode(std::string Course_Code) {code = Course_Code;}
    void setCourseNumber(std::string Course_Number) { CoNum = Course_Number;}
    void setCredits(int Cred) { Credits = Cred;}
    void setLastName(std::string Last_Name) { last = Last_Name;}
    void setCourse_Room (std::string Location) { CourseLocation = Location;}
    void SetCourseInfo();

    std::string CourseCode[20];
    std::string CourseNum[20];
    int CourseCred[20];
    std::string CourseLast[20];
    std::string CourseLoc[20];


    ~Course(){}


    void print_Courses();
    void print_Courses_Entered();


private:
    std::string code;
    std::string CoNum;
    int Credits;
    std::string last;
    std::string CourseLocation;







};
#endif // REVIEW_H
